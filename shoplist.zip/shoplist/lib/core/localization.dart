class AppLocalizations {
  static final Map<String, Map<String, String>> _localizedValues = {
    'ru': {
      'title': 'Список покупок',
      'add_hint': 'Название товара',
      'add_btn': 'Добавить',
      'settings': 'Настройки',
      'theme': 'Тёмная тема',
      'lang': 'Язык',
      'empty': 'Список пуст',
      'shopping_mode': '🛒 За покупками',
      'next_item': 'Следующий товар:',
      'finished': '✅ Все покупки завершены!',
      'bought': 'Куплено',
      'quantity': 'Кол-во',
      'delete': 'Удалить',
    },
    'en': {
      'title': 'Shopping List',
      'add_hint': 'Item name',
      'add_btn': 'Add',
      'settings': 'Settings',
      'theme': 'Dark Mode',
      'lang': 'Language',
      'empty': 'List is empty',
      'shopping_mode': '🛒 Go Shopping',
      'next_item': 'Next item:',
      'finished': '✅ Shopping finished!',
      'bought': 'Bought',
      'quantity': 'Qty',
      'delete': 'Delete',
    },
  };

  static String t(String key, String lang) {
    return _localizedValues[lang]?[key] ?? key;
  }
}