import '../../domain/entities/shopping_item.dart';
import '../../domain/repositories/items_repository.dart';
import '../local/hive_service.dart';
import 'package:uuid/uuid.dart';

class ItemsRepositoryImpl implements ItemsRepository {
  final HiveService _hiveService;
  final Uuid _uuid;

  ItemsRepositoryImpl(this._hiveService) : _uuid = const Uuid();

  @override
  Future<List<ShoppingItem>> getItems() async {
    final box = _hiveService.itemsBox;
    return box.values.map((map) {
      return ShoppingItem.fromMap(map.cast<String, dynamic>());
    }).toList();
  }

  @override
  Future<void> addItem(ShoppingItem item) async {
    final newItem = item.copyWith(id: _uuid.v4());
    await _hiveService.itemsBox.put(newItem.id, newItem.toMap());
  }

  @override
  Future<void> updateItem(ShoppingItem item) async {
    await _hiveService.itemsBox.put(item.id, item.toMap());
  }

  @override
  Future<void> deleteItem(String id) async {
    await _hiveService.itemsBox.delete(id);
  }
}