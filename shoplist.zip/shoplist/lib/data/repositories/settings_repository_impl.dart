import '../../domain/repositories/settings_repository.dart';
import '../local/hive_service.dart';

class SettingsRepositoryImpl implements SettingsRepository {
  final HiveService _hiveService;

  SettingsRepositoryImpl(this._hiveService);

  @override
  Future<bool> getIsDarkMode() async {
    return _hiveService.settingsBox.get('isDarkMode', defaultValue: false) as bool;
  }

  @override
  Future<void> setIsDarkMode(bool value) async {
    await _hiveService.settingsBox.put('isDarkMode', value);
  }

  @override
  Future<String> getLanguageCode() async {
    return _hiveService.settingsBox.get('languageCode', defaultValue: 'ru') as String;
  }

  @override
  Future<void> setLanguageCode(String code) async {
    await _hiveService.settingsBox.put('languageCode', code);
  }
}