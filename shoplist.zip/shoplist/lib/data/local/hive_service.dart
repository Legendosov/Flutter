import 'package:hive_flutter/hive_flutter.dart';

class HiveService {
  static const String itemsBoxName = 'items_box';
  static const String settingsBoxName = 'settings_box';

  Future<void> init() async {
    await Hive.initFlutter();
    if (!Hive.isBoxOpen(itemsBoxName)) {
      await Hive.openBox<Map>(itemsBoxName);
    }
    if (!Hive.isBoxOpen(settingsBoxName)) {
      await Hive.openBox(settingsBoxName);
    }
  }

  Box<Map> get itemsBox => Hive.box<Map>(itemsBoxName);
  Box get settingsBox => Hive.box(settingsBoxName);
}