import '../../domain/entities/shopping_item.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import '../widgets/item_list.dart';
import '../widgets/settings_sheet.dart';
import '../../core/localization.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsNotifierProvider);
    final lang = settings.languageCode;
    
    return Scaffold(
      appBar: AppBar(
        title: Text(AppLocalizations.t('title', lang)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                builder: (_) => const SettingsSheet(),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      hintText: AppLocalizations.t('add_hint', lang),
                      border: const OutlineInputBorder(),
                      filled: true,
                    ),
                    onSubmitted: (value) {
                      if (value.isNotEmpty) {
                        ref.read(itemsNotifierProvider.notifier).addItem(value);
                        _controller.clear();
                      }
                    },
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () {
                    if (_controller.text.isNotEmpty) {
                      ref.read(itemsNotifierProvider.notifier).addItem(_controller.text);
                      _controller.clear();
                    }
                  },
                  icon: const Icon(Icons.add),
                  label: Text(AppLocalizations.t('add_btn', lang)),
                ),
              ],
            ),
          ),
          Expanded(
            child: ItemList(lang: lang),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 50),
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              icon: const Icon(Icons.shopping_cart, size: 24),
              label: Text(
                AppLocalizations.t('shopping_mode', lang),
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              onPressed: () {
                _startShoppingMode(context, lang);
              },
            ),
          )
        ],
      ),
    );
  }

  void _startShoppingMode(BuildContext context, String lang) {
    final notifier = ref.read(itemsNotifierProvider.notifier);
    final notBought = notifier.getNotBoughtItems();
    
    if (notBought.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.t('finished', lang)),
          backgroundColor: Colors.green,
        ),
      );
      return;
    }
    
    _showNextItemDialog(context, notBought, 0, lang);
  }

  void _showNextItemDialog(BuildContext context, List<ShoppingItem> items, int index, String lang) {
    if (index >= items.length) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppLocalizations.t('finished', lang)),
          backgroundColor: Colors.green,
        ),
      );
      return;
    }

    final item = items[index];
    
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            const Icon(Icons.shopping_basket, color: Colors.blue),
            const SizedBox(width: 8),
            Text(AppLocalizations.t('next_item', lang)),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              item.name,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              '${AppLocalizations.t('quantity', lang)}: ${item.quantity}',
              style: const TextStyle(fontSize: 18, color: Colors.grey),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
            },
            child: const Text('Отмена'),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.of(ctx).pop();
              ref.read(itemsNotifierProvider.notifier).toggleBought(item.id);
              _showNextItemDialog(context, items, index + 1, lang);
            },
            icon: const Icon(Icons.check),
            label: Text(AppLocalizations.t('bought', lang)),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              foregroundColor: Colors.white,
            ),
          ),
        ],
      ),
    );
  }
}