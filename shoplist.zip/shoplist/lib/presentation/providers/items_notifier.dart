import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/entities/shopping_item.dart';
import '../../domain/repositories/items_repository.dart';

class ItemsNotifier extends StateNotifier<List<ShoppingItem>> {
  final ItemsRepository _repository;

  ItemsNotifier(this._repository) : super([]) {
    _loadItems();
  }

  Future<void> _loadItems() async {
    final items = await _repository.getItems();
    state = items;
  }

  Future<void> addItem(String name) async {
    final item = ShoppingItem(id: '', name: name);
    await _repository.addItem(item);
    await _loadItems();
  }

  Future<void> toggleBought(String id) async {
    final item = state.firstWhere((i) => i.id == id);
    final updated = item.copyWith(isBought: !item.isBought);
    await _repository.updateItem(updated);
    await _loadItems();
  }

  Future<void> changeQuantity(String id, int delta) async {
    final item = state.firstWhere((i) => i.id == id);
    final newQty = item.quantity + delta;
    if (newQty < 1) return;
    final updated = item.copyWith(quantity: newQty);
    await _repository.updateItem(updated);
    await _loadItems();
  }

  Future<void> deleteItem(String id) async {
    await _repository.deleteItem(id);
    await _loadItems();
  }

  List<ShoppingItem> getNotBoughtItems() {
    return state.where((i) => !i.isBought).toList();
  }

  Future<void> clearBoughtItems() async {
    final boughtItems = state.where((i) => i.isBought).toList();
    for (var item in boughtItems) {
      await _repository.deleteItem(item.id);
    }
    await _loadItems();
  }
}