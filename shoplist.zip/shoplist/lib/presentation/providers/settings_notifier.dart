import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/repositories/settings_repository.dart';

class AppSettings {
  final bool isDarkMode;
  final String languageCode;

  AppSettings({required this.isDarkMode, required this.languageCode});
  
  AppSettings copyWith({bool? isDarkMode, String? languageCode}) {
    return AppSettings(
      isDarkMode: isDarkMode ?? this.isDarkMode,
      languageCode: languageCode ?? this.languageCode,
    );
  }
}

class SettingsNotifier extends StateNotifier<AppSettings> {
  final SettingsRepository _repository;

  SettingsNotifier(this._repository) : super(AppSettings(isDarkMode: false, languageCode: 'ru')) {
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final isDark = await _repository.getIsDarkMode();
    final lang = await _repository.getLanguageCode();
    state = AppSettings(isDarkMode: isDark, languageCode: lang);
  }

  Future<void> toggleTheme() async {
    final newValue = !state.isDarkMode;
    state = state.copyWith(isDarkMode: newValue);
    await _repository.setIsDarkMode(newValue);
  }

  Future<void> toggleLanguage() async {
    final newLang = state.languageCode == 'ru' ? 'en' : 'ru';
    state = state.copyWith(languageCode: newLang);
    await _repository.setLanguageCode(newLang);
  }
}