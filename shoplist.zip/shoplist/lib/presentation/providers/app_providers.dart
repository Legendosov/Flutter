import '../../domain/entities/shopping_item.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../data/local/hive_service.dart';
import '../../data/repositories/items_repository_impl.dart';
import '../../data/repositories/settings_repository_impl.dart';
import '../../domain/repositories/items_repository.dart';
import '../../domain/repositories/settings_repository.dart';
import 'items_notifier.dart';
import 'settings_notifier.dart';

final hiveServiceProvider = Provider<HiveService>((ref) {
  return HiveService();
});

final itemsRepositoryProvider = Provider<ItemsRepository>((ref) {
  return ItemsRepositoryImpl(ref.watch(hiveServiceProvider));
});

final settingsRepositoryProvider = Provider<SettingsRepository>((ref) {
  return SettingsRepositoryImpl(ref.watch(hiveServiceProvider));
});

final itemsNotifierProvider = StateNotifierProvider<ItemsNotifier, List<ShoppingItem>>((ref) {
  return ItemsNotifier(ref.watch(itemsRepositoryProvider));
});

final settingsNotifierProvider = StateNotifierProvider<SettingsNotifier, AppSettings>((ref) {
  return SettingsNotifier(ref.watch(settingsRepositoryProvider));
});