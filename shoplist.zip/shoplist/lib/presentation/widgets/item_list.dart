import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import '../../core/localization.dart';

class ItemList extends ConsumerWidget {
  final String lang;
  
  const ItemList({super.key, required this.lang});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final items = ref.watch(itemsNotifierProvider);

    if (items.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.shopping_bag_outlined, size: 80, color: Colors.grey[400]),
            const SizedBox(height: 16),
            Text(
              AppLocalizations.t('empty', lang),
              style: TextStyle(fontSize: 18, color: Colors.grey[600]),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return Dismissible(
          key: Key(item.id),
          direction: DismissDirection.endToStart,
          onDismissed: (_) {
            ref.read(itemsNotifierProvider.notifier).deleteItem(item.id);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('${item.name} удалён')),
            );
          },
          background: Container(
            color: Colors.red,
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 16),
            child: const Icon(Icons.delete, color: Colors.white),
          ),
          child: Card(
            margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            child: ListTile(
              title: Text(
                item.name,
                style: TextStyle(
                  decoration: item.isBought ? TextDecoration.lineThrough : null,
                  color: item.isBought ? Colors.grey : null,
                  fontWeight: FontWeight.w500,
                ),
              ),
              subtitle: Text('${AppLocalizations.t('quantity', lang)}: ${item.quantity}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (!item.isBought) ...[
                    IconButton(
                      icon: const Icon(Icons.remove_circle_outline),
                      onPressed: () {
                        ref.read(itemsNotifierProvider.notifier).changeQuantity(item.id, -1);
                      },
                    ),
                    Text(
                      '${item.quantity}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    IconButton(
                      icon: const Icon(Icons.add_circle_outline),
                      onPressed: () {
                        ref.read(itemsNotifierProvider.notifier).changeQuantity(item.id, 1);
                      },
                    ),
                    const SizedBox(width: 8),
                  ],
                  Checkbox(
                    value: item.isBought,
                    onChanged: (val) {
                      ref.read(itemsNotifierProvider.notifier).toggleBought(item.id);
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}