import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/app_providers.dart';
import '../../core/localization.dart';

class SettingsSheet extends ConsumerWidget {
  const SettingsSheet({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsNotifierProvider);
    final notifier = ref.read(settingsNotifierProvider.notifier);
    final lang = settings.languageCode;

    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                AppLocalizations.t('settings', lang),
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
          const Divider(height: 32),
          SwitchListTile(
            title: Row(
              children: [
                Icon(Icons.brightness_6, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 12),
                Text(AppLocalizations.t('theme', lang)),
              ],
            ),
            value: settings.isDarkMode,
            onChanged: (_) => notifier.toggleTheme(),
            secondary: Icon(
              settings.isDarkMode ? Icons.dark_mode : Icons.light_mode,
            ),
          ),
          const Divider(),
          ListTile(
            leading: Icon(Icons.language, color: Theme.of(context).colorScheme.primary),
            title: Text(AppLocalizations.t('lang', lang)),
            trailing: Chip(
              label: Text(settings.languageCode.toUpperCase()),
              backgroundColor: Theme.of(context).colorScheme.primaryContainer,
            ),
            onTap: () => notifier.toggleLanguage(),
          ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}