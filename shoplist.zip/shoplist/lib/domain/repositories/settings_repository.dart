abstract class SettingsRepository {
  Future<bool> getIsDarkMode();
  Future<void> setIsDarkMode(bool value);
  Future<String> getLanguageCode();
  Future<void> setLanguageCode(String code);
}